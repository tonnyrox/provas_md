# Camara_Goiânia_2026_Legislativo_2026

## Identificação

- **Instituição**: Camara
- **Cidade**: Goiânia
- **Ano**: 2026
- **Cargo**: Legislativo
- **Banca**: N/I
- **Data**: N/I
- **Número de Questões**: 0 (a ser preenchido)

## Observações

- Prova em processamento
- Arquivos originais copiados
- Aguardando extração de conteúdo

## Arquivos


- [Gabarito - Câmara Municipal de Goiânia - GO - 2026 - Legislativo.pdf](Gabarito - Câmara Municipal de Goiânia - GO - 2026 - Legislativo.pdf)

- [Prova - Câmara Municipal de Goiânia - GO - 2026 - Legislativo.pdf](Prova - Câmara Municipal de Goiânia - GO - 2026 - Legislativo.pdf)

---

*Processado em: 2026-11-19 15:34:33*
