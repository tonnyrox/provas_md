# Relatório de análise — Camara_Clevelandia_2017_Agente_Administrativo_I

## Resumo

- Questões identificadas: **30**
- Grupos com material compartilhado: **0**
- Questões agrupadas: **0**
- Questões independentes: **30**
- Imagens extraídas: **0**
- Gabarito: **preenchido (gabarito oficial pareado — cargo AGENTE ADMINISTRATIVO I)**

| Material compartilhado | Questões vinculadas | Tipo |
|---|---|---|
| — | — | — |
